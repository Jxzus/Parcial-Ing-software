"""Sesión de juego: estado actual de una partida sobre una Historia."""
from motor.errores import OpcionNoDisponible


class Sesion:
    def __init__(self, historia):
        self._historia = historia
        self.reiniciar()

    def reiniciar(self):
        self._escena_id = self._historia.inicio
        self._variables = dict(self._historia.variables)
        self._estado_anterior = None

    @property
    def puede_deshacer(self):
        return self._estado_anterior is not None

    def deshacer(self):
        """Restaura la escena y variables previas a la última elección válida.
        Consume la posibilidad de retroceder hasta una nueva elección válida.
        Devuelve True si se deshizo, o False si no había retroceso disponible.
        """
        if self._estado_anterior is None:
            return False
        self._escena_id, self._variables = self._estado_anterior
        self._estado_anterior = None
        return True

    @property
    def escena_actual(self):
        return self._historia.escenas[self._escena_id]

    @property
    def variables(self):
        return dict(self._variables)

    @property
    def es_final(self):
        return self.escena_actual.final

    def opciones_habilitadas(self):
        return [o for o in self.escena_actual.opciones if o.habilitada(self._variables)]

    @property
    def bloqueada(self):
        """Escena no final sin opciones habilitadas."""
        return not self.es_final and not self.opciones_habilitadas()

    def elegir(self, opcion_id):
        """Aplica efectos y avanza. Si la opción no está disponible, no cambia nada."""
        habilitadas = {o.id: o for o in self.opciones_habilitadas()}
        if opcion_id not in habilitadas:
            raise OpcionNoDisponible(
                f"La opción '{opcion_id}' no existe o no está habilitada en la escena "
                f"'{self._escena_id}'.")
        opcion = habilitadas[opcion_id]
        estado_previo = (self._escena_id, dict(self._variables))
        self._variables = {**self._variables, **opcion.efectos}
        self._escena_id = opcion.destino
        self._estado_anterior = estado_previo
